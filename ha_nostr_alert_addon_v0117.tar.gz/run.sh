#!/bin/bash
# ==============================================================================
# Home Assistant Add-on: HA Nostr Alert
# ==============================================================================

# Start the Python application directly
cd /src
exec python3 -u main.py
